module.exports = {
    mongoKey: "mongodb+srv://taurus090:nfnmzy090@cluster0.5gyatwv.mongodb.net/?retryWrites=true&w=majority",
    port: 4000
}
