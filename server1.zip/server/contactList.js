module.exports = [
    {
        id: 1,
        name: 'Alex'
    },
    {
        id: 2,
        name: 'bob'
    },
    {
        id: 3,
        name: 'Charliee'
    }
]